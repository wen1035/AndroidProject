package com.cornez.activitylifecycle;

import java.util.Random;

public class Test {

    // DATA MEMBERS

    private Integer Success=0;//成功
    private Integer Wrong=0;//錯誤
    private int state = 0;//狀態->1,2 目前按幾個了
    int[]  All_E = new int[37];
    char[] All_random_English= new char[37];//隨機英文字
    private Integer[] All_t={ 0,0 };//按2個
    private Integer[] All={ 0,0,0,0,0,0,
            0,0,0,0,0,0,
            0,0,0,0,0,0,
            0,0,0,0,0,0,
            0,0,0,0,0,0,
            0,0,0,0,0,0 };

    public Test() {
        Success =0;
        Wrong =0;
    }


    public void setReset(){
        Success =0;
        Wrong =0;
        state = 0;
        for(int i=0;i<36;i++)
            All[i]=0;
        All_t[0]=0;
        All_t[1]=0;
    }

    public void setAll_t(){
        All_t[0]=0;
        All_t[1]=0;
    }

    public void addState(int str) {
        if(state==0){
            All_t[0]=str;
            state++;
        }
        else if(state==1){
            All_t[1]=str;
            state=0;
        }
        /*else if(state==2){
            state=0;
        }*/
   }

    public void setallt(int str){
        All[str]=1;
    }
    public void setallf(int str){
        All[str]=0;
    }

    public void addSuccess() {
        Success++;
    }
    public void addWrong() {
        Wrong++;
    }

    public void random() {
        Random random = new Random();
        int rand = 0;
        int i=0,N=0;
        int check_18_english=0;
        int[]  All_E = new int[37];
        int[][]  All_e = new int[27][4];
        for(int k=0;k<36;k++)
        {
            All_E[k]=0;
        }
        for(int k=0;k<26;k++)
        {
            All_e[k][1]=k+1;
            All_e[k][2]=0;
            All_e[k][3]=0;
        }

        while(All_E[35]==0)
        {

            while (true)
            {
                rand = random.nextInt(27);
                if(rand !=0)
                    break;
            }
            for(int p=0;p<26;p++)
            {
                if(All_e[p][1]==rand)
                {
                    All_e[p][2]+=1;
                    if(All_e[p][2]==1 && check_18_english< 18)
                    {
                        All_e[p][3]=1;
                        check_18_english++;
                    }
                    if(All_e[p][2]<=2 && All_e[p][3]==1)
                    {
                        All_E[N]=rand;
                        //System.out.println(All_E[N]);
                        N++;
                        break;
                    }
                }
            }

        }
        Int_to_String(All_E);
    }

    public void Int_to_String(int[] number ){
        for(int i=0;i<36;i++)
        {
            switch (number[i])
            {
                case 1:
                    All_random_English[i]='A';
                    break;
                case 2:
                    All_random_English[i]='B';
                    break;
                case 3:
                    All_random_English[i]='C';
                    break;
                case 4:
                    All_random_English[i]='D';
                    break;
                case 5:
                    All_random_English[i]='E';
                    break;
                case 6:
                    All_random_English[i]='F';
                    break;
                case 7:
                    All_random_English[i]='G';
                    break;
                case 8:
                    All_random_English[i]='H';
                    break;
                case 9:
                    All_random_English[i]='I';
                    break;
                case 10:
                    All_random_English[i]='J';
                    break;
                case 11:
                    All_random_English[i]='K';
                    break;
                case 12:
                    All_random_English[i]='L';
                    break;
                case 13:
                    All_random_English[i]='M';
                    break;
                case 14:
                    All_random_English[i]='N';
                    break;
                case 15:
                    All_random_English[i]='O';
                    break;
                case 16:
                    All_random_English[i]='P';
                    break;
                case 17:
                    All_random_English[i]='Q';
                    break;
                case 18:
                    All_random_English[i]='R';
                    break;
                case 19:
                    All_random_English[i]='S';
                    break;
                case 20:
                    All_random_English[i]='T';
                    break;
                case 21:
                    All_random_English[i]='U';
                    break;
                case 22:
                    All_random_English[i]='V';
                    break;
                case 23:
                    All_random_English[i]='W';
                    break;
                case 24:
                    All_random_English[i]='X';
                    break;
                case 25:
                    All_random_English[i]='Y';
                    break;
                case 26:
                    All_random_English[i]='Z';
                    break;
                default:
                    break;

            }

        }

    }

    public Integer getre(int str){
        return All_E[str];
    }

    public Character geten(int str){
        return All_random_English[str];
    }

    public Integer getAll_t(int str){
        return All_t[str];
    }

    public Integer getAll(int str){
        return All[str];
    }

    public Integer getSuccess() {
        return Success;
    }

    public Integer getWrong() {
        return Wrong;
    }

    public int getState() {
        return state;
    }

}
