package com.cornez.activitylifecycle;

import android.app.Activity;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Arrays;
import java.util.Random;
import android.os.Handler;

public class MyActivity extends Activity {

    private Test num;
    private TextView Success;
    private TextView Wrong;
    private TextView Show_wrong;//按鈕無效！
    //private String createMsg;
    //private String startMsg;
    //private String resumeMsg;
    //private String pauseMsg;
    //private String stopMsg;
    //private String restartMsg;


    private Button button1;
    private Button button2;
    private Button button3;
    private Button button4;
    private Button button5;
    private Button button6;
    private Button button7;
    private Button button8;
    private Button button9;
    private Button button10;
    private Button button11;
    private Button button12;
    private Button button13;
    private Button button14;
    private Button button15;
    private Button button16;
    private Button button17;
    private Button button18;
    private Button button19;
    private Button button20;
    private Button button21;
    private Button button22;
    private Button button23;
    private Button button24;
    private Button button25;
    private Button button26;
    private Button button27;
    private Button button28;
    private Button button29;
    private Button button30;
    private Button button31;
    private Button button32;
    private Button button33;
    private Button button34;
    private Button button35;
    private Button button36;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my);
        num = new Test();
        Show_wrong = (TextView) findViewById(R.id.textView1);
        Success = (TextView) findViewById(R.id.textView4);
        Wrong = (TextView) findViewById(R.id.textView5);
        // Capture our button from layout
        button1 = (Button)findViewById(R.id.button1);
        button2 = (Button)findViewById(R.id.button2);
        button3 = (Button)findViewById(R.id.button3);
        button4 = (Button)findViewById(R.id.button4);
        button5 = (Button)findViewById(R.id.button5);
        button6 = (Button)findViewById(R.id.button6);
        button7 = (Button)findViewById(R.id.button7);
        button8 = (Button)findViewById(R.id.button8);
        button9 = (Button)findViewById(R.id.button9);
        button10 = (Button)findViewById(R.id.button10);
        button11 = (Button)findViewById(R.id.button11);
        button12 = (Button)findViewById(R.id.button12);
        button13 = (Button)findViewById(R.id.button13);
        button14 = (Button)findViewById(R.id.button14);
        button15 = (Button)findViewById(R.id.button15);
        button16 = (Button)findViewById(R.id.button16);
        button17 = (Button)findViewById(R.id.button17);
        button18 = (Button)findViewById(R.id.button18);
        button19 = (Button)findViewById(R.id.button19);
        button20 = (Button)findViewById(R.id.button20);
        button21 = (Button)findViewById(R.id.button21);
        button22 = (Button)findViewById(R.id.button22);
        button23 = (Button)findViewById(R.id.button23);
        button24 = (Button)findViewById(R.id.button24);
        button25 = (Button)findViewById(R.id.button25);
        button26 = (Button)findViewById(R.id.button26);
        button27 = (Button)findViewById(R.id.button27);
        button28 = (Button)findViewById(R.id.button28);
        button29 = (Button)findViewById(R.id.button29);
        button30 = (Button)findViewById(R.id.button30);
        button31 = (Button)findViewById(R.id.button31);
        button32 = (Button)findViewById(R.id.button32);
        button33 = (Button)findViewById(R.id.button33);
        button34 = (Button)findViewById(R.id.button34);
        button35 = (Button)findViewById(R.id.button35);
        button36 = (Button)findViewById(R.id.button36);/////////////

        // Register the onClick listener with the implementation above
        button1.setOnClickListener(mCorkyListener);
        button2.setOnClickListener(mCorkyListener);
        button3.setOnClickListener(mCorkyListener);
        button4.setOnClickListener(mCorkyListener);
        button5.setOnClickListener(mCorkyListener);
        button6.setOnClickListener(mCorkyListener);
        button7.setOnClickListener(mCorkyListener);
        button8.setOnClickListener(mCorkyListener);
        button9.setOnClickListener(mCorkyListener);
        button10.setOnClickListener(mCorkyListener);
        button11.setOnClickListener(mCorkyListener);
        button12.setOnClickListener(mCorkyListener);
        button13.setOnClickListener(mCorkyListener);
        button14.setOnClickListener(mCorkyListener);
        button15.setOnClickListener(mCorkyListener);
        button16.setOnClickListener(mCorkyListener);
        button17.setOnClickListener(mCorkyListener);
        button18.setOnClickListener(mCorkyListener);
        button19.setOnClickListener(mCorkyListener);
        button20.setOnClickListener(mCorkyListener);
        button21.setOnClickListener(mCorkyListener);
        button22.setOnClickListener(mCorkyListener);
        button23.setOnClickListener(mCorkyListener);
        button24.setOnClickListener(mCorkyListener);
        button25.setOnClickListener(mCorkyListener);
        button26.setOnClickListener(mCorkyListener);
        button27.setOnClickListener(mCorkyListener);
        button28.setOnClickListener(mCorkyListener);
        button29.setOnClickListener(mCorkyListener);
        button30.setOnClickListener(mCorkyListener);
        button31.setOnClickListener(mCorkyListener);
        button32.setOnClickListener(mCorkyListener);
        button33.setOnClickListener(mCorkyListener);
        button34.setOnClickListener(mCorkyListener);
        button35.setOnClickListener(mCorkyListener);
        button36.setOnClickListener(mCorkyListener);
        //initializeMessages();

        //Toast.makeText(this, createMsg, Toast.LENGTH_LONG).show();
        num.random();
    }

    /*private void initializeMessages(){
        createMsg = (String) getResources().getText(R.string.create_message);
        startMsg = (String) getResources().getText(R.string.start_message);
        resumeMsg = (String) getResources().getText(R.string.resume_message);
        pauseMsg = (String) getResources().getText(R.string.pause_message);
        stopMsg = (String) getResources().getText(R.string.stop_message);
        restartMsg = (String) getResources().getText(R.string.restart_message);
    }*/



    private View.OnClickListener mCorkyListener = new View.OnClickListener() {
        public void onClick(View v) {
            // do something when the button is clicked
            // Yes we will handle click here but which button clicked??? We don't know

            // So we will make

            switch (v.getId() /*to get clicked view id**/) {
                case R.id.button1:

                    // do something when the corky is clicked
                    button1.setText(num.geten(0).toString());
                    comp(0);
                    break;
                case R.id.button2:

                    // do something when the corky2 is clicked
                    button2.setText(num.geten(1).toString());
                    comp(1);
                    break;
                case R.id.button3:

                    // do something when the corky3 is clicked
                    button3.setText(num.geten(2).toString());
                    comp(2);
                    break;
                case R.id.button4:

                    // do something when the corky is clicked
                    button4.setText(num.geten(3).toString());
                    comp(3);
                    break;
                case R.id.button5:

                    // do something when the corky2 is clicked
                    button5.setText(num.geten(4).toString());
                    comp(4);
                    break;
                case R.id.button6:

                    // do something when the corky3 is clicked
                    button6.setText(num.geten(5).toString());
                    comp(5);
                    break;
                case R.id.button7:

                    // do something when the corky is clicked
                    button7.setText(num.geten(6).toString());
                    comp(6);
                    break;
                case R.id.button8:

                    // do something when the corky2 is clicked
                    button8.setText(num.geten(7).toString());
                    comp(7);
                    break;
                case R.id.button9:

                    // do something when the corky3 is clicked
                    button9.setText(num.geten(8).toString());
                    comp(8);
                    break;
                case R.id.button10:

                    // do something when the corky is clicked
                    button10.setText(num.geten(9).toString());
                    comp(9);
                    break;
                case R.id.button11:

                    // do something when the corky2 is clicked
                    button11.setText(num.geten(10).toString());
                    comp(10);
                    break;
                case R.id.button12:

                    // do something when the corky3 is clicked
                    button12.setText(num.geten(11).toString());
                    comp(11);
                    break;
                case R.id.button13:

                    // do something when the corky is clicked
                    button13.setText(num.geten(12).toString());
                    comp(12);
                    break;
                case R.id.button14:

                    // do something when the corky2 is clicked
                    button14.setText(num.geten(13).toString());
                    comp(13);
                    break;
                case R.id.button15:

                    // do something when the corky3 is clicked
                    button15.setText(num.geten(14).toString());
                    comp(14);
                    break;
                case R.id.button16:

                    // do something when the corky is clicked
                    button16.setText(num.geten(15).toString());
                    comp(15);
                    break;
                case R.id.button17:

                    // do something when the corky2 is clicked
                    button17.setText(num.geten(16).toString());
                    comp(16);
                    break;
                case R.id.button18:

                    // do something when the corky3 is clicked
                    button18.setText(num.geten(17).toString());
                    comp(17);
                    break;
                case R.id.button19:

                    // do something when the corky is clicked
                    button19.setText(num.geten(18).toString());
                    comp(18);
                    break;
                case R.id.button20:

                    // do something when the corky2 is clicked
                    button20.setText(num.geten(19).toString());
                    comp(19);
                    break;
                case R.id.button21:

                    // do something when the corky3 is clicked
                    button21.setText(num.geten(20).toString());
                    comp(20);
                    break;
                case R.id.button22:

                    // do something when the corky is clicked
                    button22.setText(num.geten(21).toString());
                    comp(21);
                    break;
                case R.id.button23:

                    // do something when the corky2 is clicked
                    button23.setText(num.geten(22).toString());
                    comp(22);
                    break;
                case R.id.button24:

                    // do something when the corky3 is clicked
                    button24.setText(num.geten(23).toString());
                    comp(23);
                    break;
                case R.id.button25:

                    // do something when the corky is clicked
                    button25.setText(num.geten(24).toString());
                    comp(24);
                    break;
                case R.id.button26:

                    // do something when the corky2 is clicked
                    button26.setText(num.geten(25).toString());
                    comp(25);
                    break;
                case R.id.button27:

                    // do something when the corky3 is clicked
                    button27.setText(num.geten(26).toString());
                    comp(26);
                    break;
                case R.id.button28:

                    // do something when the corky is clicked
                    button28.setText(num.geten(27).toString());
                    comp(27);
                    break;
                case R.id.button29:

                    // do something when the corky2 is clicked
                    button29.setText(num.geten(28).toString());
                    comp(28);
                    break;
                case R.id.button30:

                    // do something when the corky3 is clicked
                    button30.setText(num.geten(29).toString());
                    comp(29);
                    break;
                case R.id.button31:

                    // do something when the corky is clicked
                    button31.setText(num.geten(30).toString());
                    comp(30);
                    break;
                case R.id.button32:

                    // do something when the corky2 is clicked
                    button32.setText(num.geten(31).toString());
                    comp(31);
                    break;
                case R.id.button33:

                    // do something when the corky3 is clicked
                    button33.setText(num.geten(32).toString());
                    comp(32);
                    break;
                case R.id.button34:

                    // do something when the corky is clicked
                    button34.setText(num.geten(33).toString());
                    comp(33);
                    break;
                case R.id.button35:

                    // do something when the corky2 is clicked
                    button35.setText(num.geten(34).toString());
                    comp(34);
                    break;
                case R.id.button36:

                    // do something when the corky3 is clicked
                    button36.setText(num.geten(35).toString());
                    comp(35);
                    break;
                default:
                    break;
            }
        }
    };


    public void click(View view){
        ;
    }


    public void comp(int str){//0-35
        if(num.getAll(str)==0){//沒被選過
            num.addState(str);//記錄下來第幾個
            num.setallt(str);//第幾個設為1
            if(num.getState()==0){//按了兩個
                if(num.geten(num.getAll_t(0))==num.geten(num.getAll_t(1)) )//A==A&&不是連按同一個 )
                {
                    num.addSuccess();
                    Success.setText(num.getSuccess().toString());
                    Wrong.setText(num.getWrong().toString());
                    Show_wrong.setText(" ");
                    num.setAll_t();
                }
                else if(num.geten(num.getAll_t(0))!=num.geten(num.getAll_t(1)))
                {
                    num.addWrong();
                    Success.setText(num.getSuccess().toString());
                    Wrong.setText(num.getWrong().toString());
                    Show_wrong.setText(" ");
                    num.setallf(num.getAll_t(0));
                    num.setallf(num.getAll_t(1));
                    //等2秒//還沒寫
                    new Handler().postDelayed(new Runnable(){
                        public void run() {
                            //SystemClock.sleep(2000);//
                            over();
                        }
                    }, 2000);//2秒
                    //num.setAll_t();
                }

            }

        }
        else if(num.getAll(str)==1)//已選過
        {
            Show_wrong.setText("按鈕無效！");

            new Handler().postDelayed(new Runnable(){
                public void run() {
                    //SystemClock.sleep(2000);
                    Show_wrong.setText("");//下一個要跑的操作
                }
            }, 2000);//2秒
        }
    }

    public void over(){
        //Show_wrong.setText(num.getAll_t(0)+"+"+num.getAll_t(1));
        for(int i=0;i<2;i++){
            if (num.getAll_t(i)==0)
                button1.setText("");
            else if (num.getAll_t(i)==1)
                button2.setText("");
            else if (num.getAll_t(i)==2)
                button3.setText("");
            else if (num.getAll_t(i)==3)
                button4.setText("");
            else if (num.getAll_t(i)==4)
                button5.setText("");
            else if (num.getAll_t(i)==5)
                button6.setText("");
            else if (num.getAll_t(i)==6)
                button7.setText("");
            else if (num.getAll_t(i)==7)
                button8.setText("");
            else if (num.getAll_t(i)==8)
                button9.setText("");
            else if (num.getAll_t(i)==9)
                button10.setText("");
            else if (num.getAll_t(i)==10)
                button11.setText("");
            else if (num.getAll_t(i)==11)
                button12.setText("");
            else if (num.getAll_t(i)==12)
                button13.setText("");
            else if (num.getAll_t(i)==13)
                button14.setText("");
            else if (num.getAll_t(i)==14)
                button15.setText("");
            else if (num.getAll_t(i)==15)
                button16.setText("");
            else if (num.getAll_t(i)==16)
                button17.setText("");
            else if (num.getAll_t(i)==17)
                button18.setText("");
            else if (num.getAll_t(i)==18)
                button19.setText("");
            else if (num.getAll_t(i)==19)
                button20.setText("");
            else if (num.getAll_t(i)==20)
                button21.setText("");
            else if (num.getAll_t(i)==21)
                button22.setText("");
            else if (num.getAll_t(i)==22)
                button23.setText("");
            else if (num.getAll_t(i)==23)
                button24.setText("");
            else if (num.getAll_t(i)==24)
                button25.setText("");
            else if (num.getAll_t(i)==25)
                button26.setText("");
            else if (num.getAll_t(i)==26)
                button27.setText("");
            else if (num.getAll_t(i)==27)
                button28.setText("");
            else if (num.getAll_t(i)==28)
                button29.setText("");
            else if (num.getAll_t(i)==29)
                button30.setText("");
            else if (num.getAll_t(i)==30)
                button31.setText("");
            else if (num.getAll_t(i)==31)
                button32.setText("");
            else if (num.getAll_t(i)==32)
                button33.setText("");
            else if (num.getAll_t(i)==33)
                button34.setText("");
            else if (num.getAll_t(i)==34)
                button35.setText("");
            else if (num.getAll_t(i)==35)
                button36.setText("");
        }
    }
    public void reset(View view){
        num.setReset();
        Success.setText("0");
        Wrong.setText("0");
        Show_wrong.setText(" ");
        button1.setText("");
        button2.setText("");
        button3.setText("");
        button4.setText("");
        button5.setText("");
        button6.setText("");
        button7.setText("");
        button8.setText("");
        button9.setText("");
        button10.setText("");
        button11.setText("");
        button12.setText("");
        button13.setText("");
        button14.setText("");
        button15.setText("");
        button16.setText("");
        button17.setText("");
        button18.setText("");
        button19.setText("");
        button20.setText("");
        button21.setText("");
        button22.setText("");
        button23.setText("");
        button24.setText("");
        button25.setText("");
        button26.setText("");
        button27.setText("");
        button28.setText("");
        button29.setText("");
        button30.setText("");
        button31.setText("");
        button32.setText("");
        button33.setText("");
        button34.setText("");
        button35.setText("");
        button36.setText("");
        num.random();
        //全按鈕false
        //All歸零
    }

    /*@Override
    protected void onStart(){
        super.onStart();
        Toast.makeText(this, startMsg, Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onResume(){
        super.onResume();
        Toast.makeText(this, resumeMsg, Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onPause(){
        super.onPause();
        Toast.makeText(this, pauseMsg, Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onStop(){
        super.onStop();
        Toast.makeText(this, stopMsg, Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onRestart(){
        super.onRestart();
        Toast.makeText(this, restartMsg, Toast.LENGTH_LONG).show();
    }*/


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.my, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
