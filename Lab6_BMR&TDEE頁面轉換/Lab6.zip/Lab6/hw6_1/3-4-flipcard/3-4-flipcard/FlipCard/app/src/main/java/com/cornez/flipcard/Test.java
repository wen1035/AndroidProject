package com.cornez.flipcard;

import java.util.Random;

public class Test {

    // DATA MEMBERS

    private Integer Success=0;//成功
    private Integer Wrong=0;//錯誤
    int suc;
    int wro;
    private int state = 0;//狀態->1,2 目前按幾個了
    int[]  All_E = new int[50];
    char[] All_random_English= new char[50];//隨機英文字
    private Integer[] All_t={ 0,0 };//按2個
    private int[] All={ 0,0,0,0,0,0,0,
                        0,0,0,0,0,0,0,
                        0,0,0,0,0,0,0,
                        0,0,0,0,0,0,0,
                        0,0,0,0,0,0,0,
                        0,0,0,0,0,0,0,
                        0,0,0,0,0,0,0};

    public Test() {
        Success =0;
        Wrong =0;
    }


    public void setReset(){
        Success =0;
        Wrong =0;
        state = 0;
        for(int i=0;i<36;i++)
            All[i]=0;
        All_t[0]=0;
        All_t[1]=0;
    }

    public void setAll_t(){
        All_t[0]=0;
        All_t[1]=0;
    }

    public void addState(int str) {
        if(state==0){
            All_t[0]=str;
            state++;
        }
        else if(state==1){
            All_t[1]=str;
            state=0;
        }
        /*else if(state==2){
            state=0;
        }*/
    }

    public void setallt(int str){
        All[str]=1;
    }
    public void setallf(int str){
        All[str]=0;
    }

    public void addSuccess() {
        Success++;
    }
    public void addWrong() {
        Wrong++;
    }

    public void random(int num) {
        Random random = new Random();
        int check_english=0;
        int check_number=0;
        int rand = 0;
        int i=0,N=0,sum=0,w=0;
        int choice=0,sumCheck=0;
        int check_18_english=0;
        int[][] number = new int [5][2];
        int[][]  All_e = new int[27][4];
        number[1][0]=16;//4*4
        number[2][0]=25;//5*5
        number[3][0]=36;//6*6
        number[4][0]=49;//7*7
        number[1][1]=8;//4*4
        number[2][1]=12;//5*5//13 is "*"
        number[3][1]=18;//6*6
        number[4][1]=24;//7*7//25 is "*"
        //choice
        for(int j=1;j<5;j++)
        {
            if(j==num-3)
            {
                choice = number[j][0];
                check_english =number[j][1];
                break;
            }
        }
        int[]  All_E = new int[choice];

        for(int k=0;k<choice;k++)
        {
            All_E[k]=0;
        }
        for(int k=0;k<26;k++)
        {
            All_e[k][1]=k+1;
            All_e[k][2]=0;
            All_e[k][3]=0;
        }

        while(All_E[choice-1]==0)
        {

            while (true)
            {
                rand = random.nextInt(27);
                if(rand !=0)
                {
                    if(w==0)
                    {
                        w++;
                        sumCheck=rand;
                    }
                    break;
                }
            }
            for(int p=0;p<26;p++)
            {
                if(All_e[p][1]==rand)
                {
                    All_e[p][2]+=1;
                    if(All_e[p][2]==1 && check_number< check_english)
                    {
                        All_e[p][3]=1;
                        check_number++;
                    }
                    if(All_e[p][2]<=2 && All_e[p][3]==1)
                    {
                        sum++;
                        if(sum == sumCheck && num!=4 &&num!=6)
                        {
                            All_E[N]=27;//is "*"
                            //System.out.println(All_E[N]);
                            N++;
                        }
                        All_E[N]=rand;
                        N++;
                        break;
                    }
                }
            }

        }
        Int_to_String(All_E);
    }

    public void random() {
        Random random = new Random();
        int rand = 0;
        int i=0,N=0;
        int check_18_english=0;
        int[]  All_E = new int[37];
        int[][]  All_e = new int[27][4];
        for(int k=0;k<36;k++)
        {
            All_E[k]=0;
        }
        for(int k=0;k<26;k++)
        {
            All_e[k][1]=k+1;
            All_e[k][2]=0;
            All_e[k][3]=0;
        }

        while(All_E[35]==0)
        {

            while (true)
            {
                rand = random.nextInt(27);
                if(rand !=0)
                    break;
            }
            for(int p=0;p<26;p++)
            {
                if(All_e[p][1]==rand)
                {
                    All_e[p][2]+=1;
                    if(All_e[p][2]==1 && check_18_english< 18)
                    {
                        All_e[p][3]=1;
                        check_18_english++;
                    }
                    if(All_e[p][2]<=2 && All_e[p][3]==1)
                    {
                        All_E[N]=rand;
                        //System.out.println(All_E[N]);
                        N++;
                        break;
                    }
                }
            }

        }
        Int_to_String(All_E);
    }

    public void Int_to_String(int[] number ){
        for(int i=0;i<number.length;i++)
        {
            switch (number[i])
            {
                case 1:
                    All_random_English[i]='A';
                    break;
                case 2:
                    All_random_English[i]='B';
                    break;
                case 3:
                    All_random_English[i]='C';
                    break;
                case 4:
                    All_random_English[i]='D';
                    break;
                case 5:
                    All_random_English[i]='E';
                    break;
                case 6:
                    All_random_English[i]='F';
                    break;
                case 7:
                    All_random_English[i]='G';
                    break;
                case 8:
                    All_random_English[i]='H';
                    break;
                case 9:
                    All_random_English[i]='I';
                    break;
                case 10:
                    All_random_English[i]='J';
                    break;
                case 11:
                    All_random_English[i]='K';
                    break;
                case 12:
                    All_random_English[i]='L';
                    break;
                case 13:
                    All_random_English[i]='M';
                    break;
                case 14:
                    All_random_English[i]='N';
                    break;
                case 15:
                    All_random_English[i]='O';
                    break;
                case 16:
                    All_random_English[i]='P';
                    break;
                case 17:
                    All_random_English[i]='Q';
                    break;
                case 18:
                    All_random_English[i]='R';
                    break;
                case 19:
                    All_random_English[i]='S';
                    break;
                case 20:
                    All_random_English[i]='T';
                    break;
                case 21:
                    All_random_English[i]='U';
                    break;
                case 22:
                    All_random_English[i]='V';
                    break;
                case 23:
                    All_random_English[i]='W';
                    break;
                case 24:
                    All_random_English[i]='X';
                    break;
                case 25:
                    All_random_English[i]='Y';
                    break;
                case 26:
                    All_random_English[i]='Z';
                    break;
                case 27:
                    All_random_English[i]='*';
                    break;
                default:
                    break;

            }

        }

    }

    public Integer getre(int str){
        return All_E[str];
    }

    public Character geten(int str){
        return All_random_English[str];
    }

    public Integer getAll_t(int str){
        return All_t[str];
    }

    public Integer getAll(int str){
        return All[str];
    }

    public Integer getSuccess() {
        return Success;
    }

    public Integer getWrong() {
        return Wrong;
    }

    public int getState() {
        return state;
    }
//////////////////////////////////////////////////////
    public int[] reall(){
        return All;
    }

    public void setall(int[] number){
        All=number;
    }

    public char[] getenall(){
        return All_random_English;
    }

    public void setenall(char[] number){
        All_random_English=number;
    }

    public int getSuc() {
        suc=Success;
        return suc;
    }

    public void setSuc(int number) {
        Success=number;
    }

    public int getwro() {
        wro=Wrong;
        return wro;
    }

    public void setwro(int number) {
        Wrong=number;
    }

}
