package com.cornez.flipcard;

import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.os.Handler;
import android.os.SystemClock;


public class AnswerActivity extends Activity implements View.OnClickListener {
    Button[] button ;
    private Test num;
    private TextView Success;
    private TextView Wrong;
    private TextView Show_wrong;//按鈕無效！
    GridLayout gridLayout;
    int numm=4;
    TextView count_num ;
    int mode;
    private int m_iSize = 0 ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_answer);
        num = new Test();
        Show_wrong = (TextView) findViewById(R.id.textView1);
        Success = (TextView) findViewById(R.id.textView4);
        Wrong = (TextView) findViewById(R.id.textView5);

        count_num = new TextView(this) ;
        count_num = (TextView)findViewById(R.id.textView3) ;

        gridLayout = (GridLayout)findViewById(R.id.root) ;
        Bundle bundle=getIntent().getExtras();
        mode=bundle.getInt("mode");
        numm=bundle.getInt("numm");
        //numm=6;


        if(mode==0){//重新開始
             num.random(numm);
            //num.random();
        }
        else if(mode==1){
            num.setenall(bundle.getCharArray("en"));
            num.setall(bundle.getIntArray("all"));
            num.setSuc(bundle.getInt("suc"));
            num.setwro(bundle.getInt("wro"));
            Success.setText(num.getSuccess().toString());
            Wrong.setText(num.getWrong().toString());
        }
        printbutton();
        Button answerBtn = (Button) findViewById(R.id.button);
        answerBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent showQuestion = new Intent(AnswerActivity.this, QuestionActivity.class);
                Bundle bundle=new Bundle();
                bundle.putInt("num",numm);
                bundle.putCharArray("en",num.getenall());
                bundle.putIntArray("all",num.reall());
                bundle.putInt("suc",num.getSuc());
                bundle.putInt("wro",num.getwro());
                showQuestion.putExtras(bundle);
                startActivity(showQuestion);
            }
        });

    }
    public void click(View view){
        ;
    }
    public void comp(int str){//0-35
        if(num.getAll(str)==0){//沒被選過
            num.addState(str);//記錄下來第幾個
            num.setallt(str);//第幾個設為1
            if(num.getState()==0)
            {
                //按了兩個
                if(num.geten(num.getAll_t(0))==num.geten(num.getAll_t(1)) )//A==A&&不是連按同一個 )
                {
                    num.addSuccess();
                    Success.setText(num.getSuccess().toString());
                    Wrong.setText(num.getWrong().toString());
                    Show_wrong.setText(" ");
                    num.setAll_t();
                }
                else if(num.geten(num.getAll_t(0))!=num.geten(num.getAll_t(1)))
                {
                    num.addWrong();
                    Success.setText(num.getSuccess().toString());
                    Wrong.setText(num.getWrong().toString());
                    Show_wrong.setText(" ");
                    num.setallf(num.getAll_t(0));
                    num.setallf(num.getAll_t(1));
                    //等2秒//還沒寫
                    new Handler().postDelayed(new Runnable(){
                        public void run() {
                            over();
                        }
                    }, 2000);//2秒
                }

            }

        }
        else if(num.getAll(str)==1)//已選過
        {
            Show_wrong.setText("按鈕無效！");

            new Handler().postDelayed(new Runnable(){
                public void run() {
                    //SystemClock.sleep(2000);
                    Show_wrong.setText("");//下一個要跑的操作
                }
            }, 2000);//2秒
        }
    }

    private void printbutton(){
        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics); //抓取螢幕大小的資料
        int with = 1000 ;
        button = new Button[numm*numm] ;
        gridLayout.removeAllViews();
        gridLayout.setColumnCount(1);           // 設定GridLayout有幾行
        gridLayout.setRowCount(numm);              // 設定GridLayout有幾列
        m_iSize = numm;
        for(int id=0;id<numm*numm;id++)
        {
            for (int i = 0; i < m_iSize; i++)
            {
                //設置TableRow和其屬性
                TableRow row = new TableRow(this);//生成row的空間
                row.setGravity(Gravity.CENTER_HORIZONTAL);//橫向置中

                for (int j = 0; j < m_iSize; j++) {
                    //Button button = new Button(this); //製作row裡的button
                    button[m_iSize*i+j] = new Button(this) ;
                    button[m_iSize*i+j].setId(id);              // 設定Button的ID
                    id++;
                    row.addView(button[m_iSize*i+j]); //將button放到row
                    //i*m_iSize+j為序號
                    if(num.getAll(m_iSize*i+j)==1)
                        button[m_iSize*i+j].setText(num.geten(m_iSize*i+j).toString()); // 設定Button中的的字
                    else
                        button[m_iSize*i+j].setText(""); // 設定Button中的的字
                    button[m_iSize*i+j].setOnClickListener(this); //讓按鈕可被監聽
                    button[m_iSize*i+j].setTextSize(16); //按鈕內字的大小
                    button[m_iSize*i+j].setPadding(0, 0, 0, 0); //按鈕內文字與邊界大小
                    //button.setBackgroundResource(R.drawable.button_style); //設置按鈕外觀/背景
                    button[m_iSize*i+j].getLayoutParams().width = 1000/m_iSize;//(m_binding.bingoTable.getWidth()) / m_iSize; //設置按鈕長寬
                    button[m_iSize*i+j].getLayoutParams().height = 1000/m_iSize;// (m_binding.bingoTable.getHeight()) / m_iSize; //監測table大小後，依table大小生成對應比例的按鈕
                }
                gridLayout.addView(row);//, i); //將row加到table裡
            }
        }

    }

    public void over(){
        for(int i=0;i<2;i++){
            for(int j=0;j<numm*numm;j++){
                if(num.getAll_t(i)==j)
                    button[j].setText("");
            }
        }
    }

    @Override
    public void onClick(View v) {

        String temp = (String) count_num.getText(); // 抓取Text裡面的字串
        for(int i = 0 ; i < numm*numm ; i++) {
            if( v.getId() == button[i].getId() ){
                button[i].setText(num.geten(i).toString()); // 設定Button中的的字
                comp(i);
            }
        }

    }

    @Override
    protected void onStart() {
        super.onStart();
        overridePendingTransition(R.anim.question_in, R.anim.answer_out);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        //getMenuInflater().inflate(R.menu.my, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}

