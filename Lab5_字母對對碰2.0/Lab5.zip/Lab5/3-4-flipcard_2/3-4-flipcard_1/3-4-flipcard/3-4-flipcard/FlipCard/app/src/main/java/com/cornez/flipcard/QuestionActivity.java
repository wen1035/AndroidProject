
package com.cornez.flipcard;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TableRow;
import android.widget.TextView;////////////
import android.content.Context;
import android.widget.SeekBar;
import android.widget.Toast;

import java.util.ArrayList;


public class QuestionActivity extends Activity implements View.OnClickListener {

    private TextView seekBartextView;
    private SeekBar seekBar;
    private Context Context;
    Button[] button ;
    char[] en;
    int[]  all;
    int suc;
    int wro;
    TextView count_num ;
    int num=4;
    GridLayout gridLayout;
    Bundle bundle;
    /////////////////////////////////////////////////////////////////////

   private int m_iSize = 0 ;
    ///////////////////////////////////////////////////////////////////
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question);
        if(getIntent().getExtras()!=null){
            bundle=getIntent().getExtras();
            num=bundle.getInt("num");
        }
        count_num = new TextView(this) ;

        gridLayout = (GridLayout)findViewById(R.id.root) ;


        printbutton();
        Context = QuestionActivity.this;//
        bindViews();//

        Button answerBtn = (Button) findViewById(R.id.restart);
        answerBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent showAnswer = new Intent(QuestionActivity.this, AnswerActivity.class);
                bundle=new Bundle();
                bundle.putInt("mode",0);
                bundle.putInt("numm",num);
                showAnswer.putExtras(bundle);
                startActivity(showAnswer);
            }
        });

        Button contiBtn = (Button) findViewById(R.id.conti);
        contiBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                if(getIntent().getExtras()!=null){
                    Intent showAnswer = new Intent(QuestionActivity.this, AnswerActivity.class);
                    bundle=getIntent().getExtras();
                    num=bundle.getInt("num");
                    en=bundle.getCharArray("en");
                    all=bundle.getIntArray("all");
                    suc=bundle.getInt("suc");
                    wro=bundle.getInt("wro");
                    bundle=new Bundle();
                    bundle.putInt("mode",1);
                    bundle.putInt("numm",num);
                    bundle.putCharArray("en",en);
                    bundle.putIntArray("all",all);
                    bundle.putInt("suc",suc);
                    bundle.putInt("wro",wro);
                    showAnswer.putExtras(bundle);
                    startActivity(showAnswer);
                }
                else
                    ;
            }
        });
    }


    ///////////////////////////////////////////////////////////////////////

    private void printbutton(){
        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics); //抓取螢幕大小的資料
        int with = 1000 ;
        button = new Button[num*num] ;
        gridLayout.removeAllViews();
        gridLayout.setColumnCount(1);           // 設定GridLayout有幾行
        gridLayout.setRowCount(num);              // 設定GridLayout有幾列
        m_iSize = num;
        for(int id=0;id<num*num;id++)
        {   for (int i = 0; i < m_iSize; i++)
            {
                //設置TableRow和其屬性
                TableRow row = new TableRow(this);//生成row的空間
                row.setGravity(Gravity.CENTER_HORIZONTAL);//橫向置中

                for (int j = 0; j < m_iSize; j++) {
                    Button button = new Button(this); //製作row裡的button
                    button.setId(id);              // 設定Button的ID
                    id++;
                    row.addView(button); //將button放到row
                    //i*m_iSize+j為序號
                    button.setText(""); //將生成button內的文字設空值
                    button.setOnClickListener(this); //讓按鈕可被監聽
                    button.setTextSize(16); //按鈕內字的大小
                    button.setPadding(0, 0, 0, 0); //按鈕內文字與邊界大小
                    //button.setBackgroundResource(R.drawable.button_style); //設置按鈕外觀/背景
                    button.getLayoutParams().width = 1000/m_iSize;//(m_binding.bingoTable.getWidth()) / m_iSize; //設置按鈕長寬
                    button.getLayoutParams().height = 1000/m_iSize;// (m_binding.bingoTable.getHeight()) / m_iSize; //監測table大小後，依table大小生成對應比例的按鈕
                }
                gridLayout.addView(row);//, i); //將row加到table裡
            }
        }

    }


    /*public class BingoButton {
        private Button m_btnButton = null;
        private boolean m_bButtonStatus = false;
        private int m_NumberSave = 0;

        public BingoButton(Button btnButton, int iTag) {
            m_btnButton = btnButton;
            m_btnButton.setTag(iTag);
        }

        public Button getButton() {
            return m_btnButton;
        }
    }

    private void printBingoButton() {
        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics); //抓取螢幕大小的資料
        int with = metrics.widthPixels/6 ;        // 螢幕的寬度/4放近with
        gridLayout.removeAllViews();
        gridLayout.setColumnCount(1);           // 設定GridLayout有幾行
        gridLayout.setRowCount(num);              // 設定GridLayout有幾列
        m_iSize = num;
        for (int i = 0; i < m_iSize; i++) {
            //設置TableRow和其屬性
            TableRow row = new TableRow(this);//生成row的空間
            row.setGravity(Gravity.CENTER_HORIZONTAL);//橫向置中

            for (int j = 0; j < m_iSize; j++) {
                Button button = new Button(this); //製作row裡的button
                BingoButton bingoButton = new BingoButton(button, i * m_iSize + j); //將button 放進bingobutton類別&設tag
                row.addView(button); //將button放到row
                m_alBingoButtons.add(bingoButton); //將生成button加到陣列裡
                //i*m_iSize+j為序號
                button.setText(""); //將生成button內的文字設空值
                button.setOnClickListener(bingoOnClickListener); //讓按鈕可被監聽
                button.setTextSize(16); //按鈕內字的大小
                button.setPadding(0, 0, 0, 0); //按鈕內文字與邊界大小
                //button.setBackgroundResource(R.drawable.button_style); //設置按鈕外觀/背景
                button.getLayoutParams().width = 1000/m_iSize;//(m_binding.bingoTable.getWidth()) / m_iSize; //設置按鈕長寬
                button.getLayoutParams().height = 1000/m_iSize;// (m_binding.bingoTable.getHeight()) / m_iSize; //監測table大小後，依table大小生成對應比例的按鈕
            }
            gridLayout.addView(row);//, i); //將row加到table裡
        }

    }
    private Button.OnClickListener bingoOnClickListener = new Button.OnClickListener() {
        @Override
        public void onClick(View v) {

        }
    };*/

    ////////////////////////////////////////
    private void bindViews() {
        seekBar = (SeekBar) findViewById(R.id.seekBar);
        seekBartextView = (TextView) findViewById(R.id.seekBartextView);
        seekBar.setProgress(num);
        seekBartextView.setText("大小設定：" + num );
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                seekBartextView.setText("大小設定：" + progress );
                num=progress;
                printbutton();


            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                ;//Toast.makeText(Context, "按住SeekBar", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                ;//Toast.makeText(Context, "放開SeekBar", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        overridePendingTransition(R.anim.answer_in, R.anim.question_out);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu
        getMenuInflater().inflate(R.menu.question, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    public void onClick(View v) {
        /*String temp = (String) count_num.getText(); // 抓取Text裡面的字串
        for(int i = 0 ; i < 25 ; i++) {
            if( v.getId() == button[i].getId() ){
                temp = temp +"+" + (i+1) ;  // 把字串加長"+i"
                count_num.setText(temp);   // 顯示
            }
        }*/
        ;
    }
}
