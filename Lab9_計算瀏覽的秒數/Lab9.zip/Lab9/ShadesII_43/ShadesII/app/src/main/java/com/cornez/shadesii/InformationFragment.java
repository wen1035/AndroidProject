package com.cornez.shadesii;

import android.app.Fragment;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class InformationFragment extends Fragment {
    /*private TextView countTextView;
    private Integer count;
    InformationFragment fragment2;
    int i=0;
    Thread thread ;*/

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.information_fragment, container, false);
        return view;

    }

    public void setText (String item) {
        TextView view = (TextView) getView().findViewById(R.id.textView1);
        view.setText(item);
    }

    public void setTextt (String item) {
        TextView view = (TextView) getView().findViewById(R.id.textView);
        view.setText(item);

        /*if(i!=0)
            thread.interrupt();
        thread = new Thread(countNumbers);
        i++;
        count = 0;

        //CREATE A THREAD AND START IT

        thread.start();*/
    }


    /*private Runnable countNumbers = new Runnable () {
        private static final int DELAY = 1000;
        public void run() {

            try {
                while (true) {
                    count ++;
                    thread.sleep(DELAY);
                    threadHandler.sendEmptyMessage(0);
                }
            } catch (InterruptedException e){
                e.printStackTrace();
            }
        }
    };

    public Handler threadHandler = new Handler() {
        public void handleMessage (android.os.Message message){
            TextView view = (TextView) getView().findViewById(R.id.textView);
            view.setText("Browsing time: "+count.toString()+"sec.");
            //fragment2.setTextt("Browsing time: "+count.toString()+"sec.");
        }

    };*/

}
