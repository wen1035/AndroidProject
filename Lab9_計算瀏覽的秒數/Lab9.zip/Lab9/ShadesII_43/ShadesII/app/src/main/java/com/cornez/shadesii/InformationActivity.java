package com.cornez.shadesii;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;
import android.view.Menu;
import android.view.MenuItem;

public class InformationActivity extends Activity {


    private TextView countTextView;
    private Integer count;

    public static final String EXTRA_URL = "url";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Need to check if Activity has been switched to landscape mode
        // If yes, finished and go back to the start Activity
        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
            finish();
            return;
        }
        setContentView(R.layout.information_fragment);

        //SHOW THE UP BUTTON IN THE ACTION BAR
        getActionBar().setDisplayHomeAsUpEnabled(true);

        Intent intent = getIntent();
        String informationValue = intent.getStringExtra("Information");

        TextView info = (TextView) findViewById (R.id.textView1);
        info.setText(informationValue);

        //REFERENCE THE TEXTVIEW UI ELEMENT ON THE LAYOUT
        countTextView = (TextView) findViewById(R.id.textView);
        countTextView.setText("Browsing time: 1sec.");
        //INITIALIZE THE COUNTER
        count = 0;

        //CREATE A THREAD AND START IT
        Thread thread = new Thread (countNumbers);
        thread.start();

    }

    @Override
    protected void onStart() {
        super.onStart();
        count = 0;
    }

    private Runnable countNumbers = new Runnable () {
        private static final int DELAY = 1000;
        public void run() {
            try {
                while (true) {
                    count ++;
                    Thread.sleep (DELAY);
                    threadHandler.sendEmptyMessage(0);
                }
            } catch (InterruptedException e){
                e.printStackTrace();
            }
        }
    };

    public Handler threadHandler = new Handler() {
        public void handleMessage (android.os.Message message){
            countTextView.setText("Browsing time: "+count.toString()+"sec.");
        }

    };

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.my, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
