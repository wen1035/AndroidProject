package com.cornez.shadesii;

import static java.lang.Thread.yield;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;



public class MyActivity extends Activity implements
        MyListFragment.OnItemSelectedListener {

    private TextView countTextView;
    private Integer count;
    InformationFragment fragment2;
    int i=0;
    Thread thread ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my);
        /*Configuration configuration = getResources().getConfiguration();
        if (i!=0 && configuration.orientation == Configuration.ORIENTATION_PORTRAIT){
            thread.interrupt();
        }*/
    }

    @Override
    public void onColorItemSelected(String link) {
        fragment2 = (InformationFragment) getFragmentManager()
                .findFragmentById(R.id.fragment2);

        //A TWO PANE CONFIGURATION
        if (fragment2 != null && fragment2.isInLayout()) {
            fragment2.setText(link);

            fragment2.setTextt("Browsing time: 1sec.");
            if(i!=0)
                thread.interrupt();
            thread = new Thread(countNumbers);
            i++;
            count = 0;

            //CREATE A THREAD AND START IT

            thread.start();

        }
        //A SINGLE-PANE CONFIGURATION -
        //  IF FRAGMENT 2 DOES NOT EXIST IN THIS LAYOUT, THEN ACTIVATE THE NEXT ACTIVITY
        else {
            Intent intent = new Intent (this, InformationActivity.class);
            intent.putExtra("Information", link);
            startActivity (intent);
        }

    }

    @Override
    protected void onStart() {
        super.onStart();
        count = 0;
    }

    private Runnable countNumbers = new Runnable () {
        private static final int DELAY = 1000;
        public void run() {

            try {
                while (true) {
                    count ++;
                    thread.sleep(DELAY);
                    if (fragment2 != null && fragment2.isInLayout())
                        threadHandler.sendEmptyMessage(0);
                }
            } catch (InterruptedException e){
                e.printStackTrace();
            }
        }
    };

    public Handler threadHandler = new Handler() {
        public void handleMessage (android.os.Message message){
            fragment2.setTextt("Browsing time: "+count.toString()+"sec.");
        }

    };

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.my, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
