package com.cornez.flipcard;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.InputFilter;


import android.util.DisplayMetrics;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Spinner;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;


public class QuestionActivity extends Activity {
    //DATA MODEL FOR SHIP ITEM
    private ShipItem num;

    //VIEW OBJECTS FOR LAYOUT UI REFERENCE
    private EditText Weight;
    private EditText Height;
    private EditText Age;
    private TextView bg;
    private Spinner sp;
    double weight;
    double height;
    int age;
    boolean bbgg;
    int state;
    boolean user1;
    boolean user2;
    private TextView text;

    private Button day;
    private Button intro;
    private Button lu1;
    private Button su1;
    private Button lu2;
    private Button su2;
    Bundle bundle;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Finish all the acitivities of the application
        if(getIntent().getBooleanExtra("EXIT", false)){//根據EXIT值關閉A
            finish();
            return;
        }

        setContentView(R.layout.question);

        //CREATE THE DATA MODEL FOR STORING THE ITEM TO BE SHIPPED
        num = new ShipItem();

        //TASK 3: ESTABLISH THE REFERENCES TO INPUT WEIGHT ELEMENT
        Height = (EditText) findViewById(R.id.editText1);
        Weight = (EditText) findViewById(R.id.editText2);
        Age = (EditText) findViewById(R.id.editText3);
        bg = (TextView) findViewById(R.id.bg);
        text = (TextView) findViewById(R.id.text);

        String[] set={"沒啥運動","每周運動 1-3 天","每周運動 3-5 天","每周運動 6-7 天","無時無刻都在運動"};
        sp =(Spinner)findViewById(R.id.spinner1);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.set, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //ArrayAdapter<String> adapter=new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,set);
        sp.setAdapter(adapter);
        sp.setOnItemSelectedListener(spnOnItemSelected);

        if(getIntent().getExtras()!=null) {
            bundle = getIntent().getExtras();
            num.set(bundle.getDouble("h"), bundle.getDouble("w"), bundle.getInt("age"), bundle.getBoolean("bg"),bundle.getInt("mode"));
            Weight.setText(num.getWeight().toString());
            Height.setText(num.getHeight().toString());
            Age.setText(num.getAge().toString());

            sp.setSelection(num.getmode()-1, false);

        }
        if(num.getbg())
            bg.setText("男生");//男生1
        else
            bg.setText("女生");//女生2

        //TASK 4: REGISTER THE LISTENER EVENT FOR WEIGHT INPUT
        //Weight.addTextChangedListener(weightTextWatcher);
        Weight.addTextChangedListener(new DecimalInputTextWatcher(Weight, 5, 1));
        Height.addTextChangedListener(new DecimalInputTextWatcher(Height, 5, 1));
        Weight.addTextChangedListener(weightTextWatcher);
        Height.addTextChangedListener(weightTextWatcher);
        Age.addTextChangedListener(weightTextWatcher);
        bg.addTextChangedListener(weightTextWatcher);
        user1_user2_T_or_F();

        day = (Button) findViewById(R.id.day);
        day.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent showQuestion = new Intent(QuestionActivity.this, AnswerActivity.class);
                bundle = new Bundle();
                bundle.putDouble("w",num.getWeight());
                bundle.putDouble("h",num.getHeight());
                bundle.putInt("age",num.getAge());
                bundle.putInt("mode",num.getmode());
                bundle.putBoolean("bg",num.getbg());
                showQuestion.putExtras(bundle);
                startActivity(showQuestion);
                overridePendingTransition(R.anim.answer_in, R.anim.question_out);
                if(getIntent().getExtras()!=null)
                    finish();
            }


        });

        intro = (Button) findViewById(R.id.intro);
        intro.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent showQuestion = new Intent(QuestionActivity.this, IntroActivity.class);
                bundle = new Bundle();
                bundle.putDouble("w",num.getWeight());
                bundle.putDouble("h",num.getHeight());
                bundle.putInt("age",num.getAge());
                bundle.putInt("mode",num.getmode());
                bundle.putBoolean("bg",num.getbg());
                showQuestion.putExtras(bundle);
                startActivity(showQuestion);
                overridePendingTransition(R.anim.question_in, R.anim.answer_out);
                if(getIntent().getExtras()!=null)
                    finish();
            }
        });

        lu1 = (Button) findViewById(R.id.lu1);
        lu1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                if(user1) {
                SharedPreferences sharedPreferences = getSharedPreferences("User1", Context.MODE_PRIVATE);
                    if(sharedPreferences.getString("h", "").isEmpty()&&sharedPreferences.getString("w", "").isEmpty()&&sharedPreferences.getInt("age", 0) == 0){
                        text.setText("尚未有資料，請輸入!");
                    }
                    else{
                        String str = "請輸入";
                        if (sharedPreferences.getString("h", "0.0").isEmpty()){
                            str+=" 身高 ";
                            height=0.0;
                        }
                        else
                            height = Double.parseDouble(sharedPreferences.getString("h", "0.0"));

                        if (sharedPreferences.getString("w", "0.0").isEmpty()){
                            str+=" 體重 ";
                            weight=0.0;
                        }
                        else
                            weight = Double.parseDouble(sharedPreferences.getString("w", "0.0"));

                        //lu1.setText(sharedPreferences.getInt("age", 0));
                        if (sharedPreferences.getInt("age", 0) == 0){
                            str+=" 年齡 ";
                            age=0;
                        }
                        else
                            age = sharedPreferences.getInt("age", 0);

                        if(str.length()<4)
                            str="";
                        text.setText(str);


                        bbgg = sharedPreferences.getBoolean("bg", true);
                        state = sharedPreferences.getInt("mode", 1);

                        num.set(height, weight, age, bbgg, state );
                        Weight.setText(num.getWeight().toString());//su1.setText(num.getHeight().toString());
                        num.set(height, weight, age, bbgg, state );
                        Height.setText(num.getHeight().toString());//lu1.setText(num.getHeight().toString());
                        num.set(height, weight, age, bbgg, state );
                        Age.setText(num.getAge().toString());
                        num.set(height, weight, age, bbgg, state );
                        sp.setSelection(num.getmode() - 1, false);
                        if (num.getbg())
                            bg.setText("男生");//男生1
                        else
                            bg.setText("女生");//女生2

                    }
                }
                else
                {
                    text.setText("尚未有資料，請輸入!");

                }
            }
        });

        su1 = (Button) findViewById(R.id.su1);
        su1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                //comp(user1);
                user1=true;
                //text.setText(Weight.getText().toString());
                //text.setText("");
                SharedPreferences sharedPreferences= getSharedPreferences("User1", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor= sharedPreferences.edit();
                editor.putString("w",Weight.getText().toString());
                editor.putString("h",Height.getText().toString());
                editor.putInt("age",num.getAge());
                editor.putInt("mode",num.getmode());
                editor.putBoolean("bg",num.getbg());
                editor.commit();
                editor.apply();

                if(user1) {
                    //SharedPreferences sharedPreferences = getSharedPreferences("User1", Context.MODE_PRIVATE);
                    if(sharedPreferences.getString("h", "").isEmpty()&&sharedPreferences.getString("w", "").isEmpty()&&sharedPreferences.getInt("age", 0) == 0){
                        text.setText("尚未有資料，請輸入!");
                    }
                    else{
                        String str = "請輸入";
                        if (sharedPreferences.getString("h", "").isEmpty()){
                            str+=" 身高 ";
                            height=0.0;
                        }
                        else
                            height = Double.parseDouble(sharedPreferences.getString("h", "0.0"));

                        if (sharedPreferences.getString("w", "").isEmpty()){
                            str+=" 體重 ";
                            weight=0.0;
                        }
                        else
                            weight = Double.parseDouble(sharedPreferences.getString("w", "0.0"));

                        //lu1.setText(sharedPreferences.getInt("age", 0));
                        if (sharedPreferences.getInt("age", 0) == 0){
                            str+=" 年齡 ";
                            age=0;
                        }
                        else
                            age = sharedPreferences.getInt("age", 0);

                        if(str.length()<4)
                            str="";
                        text.setText(str);


                    }
                }
            }
        });

        lu2 = (Button) findViewById(R.id.lu2);
        lu2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                if(user2) {
                    SharedPreferences sharedPreferences = getSharedPreferences("User2", Context.MODE_PRIVATE);
                    if(sharedPreferences.getString("h", "").isEmpty()&&sharedPreferences.getString("w", "").isEmpty()&&sharedPreferences.getInt("age", 0) == 0){
                        text.setText("尚未有資料，請輸入!");
                    }
                    else{
                        String str = "請輸入";
                        if (sharedPreferences.getString("h", "").isEmpty()){
                            str+=" 身高 ";
                            height=0.0;
                        }
                        else
                            height = Double.parseDouble(sharedPreferences.getString("h", "0.0"));

                        if (sharedPreferences.getString("w", "").isEmpty()){
                            str+=" 體重 ";
                            weight=0.0;
                        }
                        else
                            weight = Double.parseDouble(sharedPreferences.getString("w", "0.0"));

                        //lu1.setText(sharedPreferences.getInt("age", 0));
                        if (sharedPreferences.getInt("age", 0) == 0){
                            str+=" 年齡 ";
                            age=0;
                        }
                        else
                            age = sharedPreferences.getInt("age", 0);

                        if(str.length()<4)
                            str="";
                        text.setText(str);

                        bbgg = sharedPreferences.getBoolean("bg", true);
                        state = sharedPreferences.getInt("mode", 1);

                        num.set(height, weight, age, bbgg, state);
                        Weight.setText(num.getWeight().toString());//su1.setText(num.getHeight().toString());
                        num.set(height, weight, age, bbgg, state);
                        Height.setText(num.getHeight().toString());//lu1.setText(num.getHeight().toString());
                        num.set(height, weight, age, bbgg, state);
                        Age.setText(num.getAge().toString());
                        num.set(height, weight, age, bbgg, state);
                        sp.setSelection(num.getmode() - 1, false);
                        if (num.getbg())
                            bg.setText("男生");//男生1
                        else
                            bg.setText("女生");//女生2

                    }
                }
                else
                {
                    text.setText("尚未有資料，請輸入!");

                }
            }
        });

        su2 = (Button) findViewById(R.id.su2);
        su2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                user2=true;
                text.setText("");
                SharedPreferences sharedPreferences= getSharedPreferences("User2", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor= sharedPreferences.edit();
                editor.putString("w",Weight.getText().toString());
                editor.putString("h",Height.getText().toString());
                editor.putInt("age",num.getAge());
                editor.putInt("mode",num.getmode());
                editor.putBoolean("bg",num.getbg());
                editor.commit();
                editor.apply();
                if(user2) {
                    //SharedPreferences sharedPreferences = getSharedPreferences("User1", Context.MODE_PRIVATE);
                    if(sharedPreferences.getString("h", "") .isEmpty()&&sharedPreferences.getString("w", "").isEmpty()&&sharedPreferences.getInt("age", 0) == 0){
                        text.setText("尚未有資料，請輸入!");
                    }
                    else{
                        String str = "請輸入";
                        if (sharedPreferences.getString("h", "").isEmpty()){
                            str+=" 身高 ";
                            height=0.0;
                        }
                        else
                            height = Double.parseDouble(sharedPreferences.getString("h", "0.0"));

                        if (sharedPreferences.getString("w", "").isEmpty()){
                            str+=" 體重 ";
                            weight=0.0;
                        }
                        else
                            weight = Double.parseDouble(sharedPreferences.getString("w", "0.0"));

                        //lu1.setText(sharedPreferences.getInt("age", 0));
                        if (sharedPreferences.getInt("age", 0) == 0){
                            str+=" 年齡 ";
                            age=0;
                        }
                        else
                            age = sharedPreferences.getInt("age", 0);

                        if(str.length()<4)
                            str="";
                        text.setText(str);


                    }
                }
            }
        });
    }

    private void user1_user2_T_or_F()
    {
        SharedPreferences sharedPreferences1 = getSharedPreferences("User1", Context.MODE_PRIVATE);
        if(sharedPreferences1.getString("h", "") != "" || sharedPreferences1.getString("w", "") != "" || sharedPreferences1.getInt("age", 0) != 0){
            user1=true;
        }
        SharedPreferences sharedPreferences2 = getSharedPreferences("User2", Context.MODE_PRIVATE);
        if(sharedPreferences2.getString("h", "") != "" || sharedPreferences2.getString("w", "") != "" || sharedPreferences2.getInt("age", 0) != 0){
            user2=true;
        }
    }



    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        //橫豎屏切換前調用，保存用戶想要保存的數據，以下是樣例

        outState.putDouble("w",num.getWeight());
        outState.putDouble("h",num.getHeight());
        outState.putInt("age",num.getAge());
        outState.putInt("mode",num.getmode());
        outState.putBoolean("bg",num.getbg());
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        // 屏幕切換完畢後調用用戶存儲的數據，以下爲樣例：
        if(savedInstanceState != null) {
            int age = savedInstanceState.getInt("age");
            int mode = savedInstanceState.getInt("mode");
            double w = savedInstanceState.getDouble("w");
            double h = savedInstanceState.getDouble("h");
            boolean bbg = savedInstanceState.getBoolean("bg");
            num.set(h,w,age,bbg,mode);
            if(num.getbg())
                bg.setText("男生");//男生1
            else
                bg.setText("女生");//女生2
        }
    }

    private AdapterView.OnItemSelectedListener spnOnItemSelected
            = new AdapterView.OnItemSelectedListener() {
        public void onItemSelected(AdapterView<?> parent, View view,
                                   int pos, long id) {
            try {
                //num.mode(sp.getSelectedItemPosition());
                num.set(Double.parseDouble(Height.getText().toString()),Double.parseDouble(Weight.getText().toString()), Integer.parseInt(Age.getText().toString()),num.getbg(),sp.getSelectedItemPosition()+1);
            }catch (NumberFormatException e){
                num.set(0,0, 0,num.getbg(),1);
            }
            //comp();

        }

        public void onNothingSelected(AdapterView<?> parent) {

        }
    };

    //private TextWatcher weightTextWatcher = new TextWatcher() {
    public class DecimalInputTextWatcher implements TextWatcher{
        //THE INPUT ELEMENT IS ATTACHED TO AN EDITABLE,
        //THEREFORE THESE METHODS ARE CALLED WHEN THE TEXT IS CHANGED

        private static final int DEFAULT_DECIMAL_DIGITS = 2;//預設 小數的位數  2 位

        private EditText editText;
        private int decimalDigits;// 小數的位數
        private int integerDigits;// 整數的位數

        public DecimalInputTextWatcher(EditText editText) {
            this.editText = editText;
            this.decimalDigits = DEFAULT_DECIMAL_DIGITS;
        }

        public DecimalInputTextWatcher(EditText editText, int decimalDigits) {
            this.editText = editText;
            if (decimalDigits <= 0)
                throw new RuntimeException("decimalDigits must > 0");
            this.decimalDigits = decimalDigits;
        }

        public DecimalInputTextWatcher(EditText editText, int integerDigits, int decimalDigits) {
            this.editText = editText;
            if (integerDigits <= 0)
                throw new RuntimeException("integerDigits must > 0");
            if (decimalDigits <= 0)
                throw new RuntimeException("decimalDigits must > 0");
            this.decimalDigits = decimalDigits;
            this.integerDigits = integerDigits;
        }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

        }

        @Override
        public void afterTextChanged(Editable editable) {
            String s = editable.toString();
            editText.removeTextChangedListener(this);

            if (s.contains(".")) {
                if (integerDigits > 0) {
                    editText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(integerDigits + decimalDigits + 1)});
                }
                if (s.length() - 1 - s.indexOf(".") > decimalDigits) {
                    s = s.substring(0,
                            s.indexOf(".") + decimalDigits + 1);
                    editable.replace(0, editable.length(), s.trim());//不輸入超出位數的數字
                }
            } else {
                if (integerDigits > 0) {
                    editText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(integerDigits + 1)});
                    if (s.length() > integerDigits) {
                        s = s.substring(0, integerDigits);
                        editable.replace(0, editable.length(), s.trim());
                    }
                }

            }
            if (s.trim().equals(".")) {//小數點開頭，小數點前補0
                s = "0" + s;
                editable.replace(0, editable.length(), s.trim());
            }
            if (s.startsWith("0") && s.trim().length() > 1) {//多個0開頭，只輸入一個0
                if (!s.substring(1, 2).equals(".")) {
                    editable.replace(0, editable.length(), "0");
                }
            }
            editText.addTextChangedListener(this);
        }
    };


    private TextWatcher weightTextWatcher = new TextWatcher() {
        //THE INPUT ELEMENT IS ATTACHED TO AN EDITABLE,
        //THEREFORE THESE METHODS ARE CALLED WHEN THE TEXT IS CHANGED

        public void onTextChanged(CharSequence s,
                                  int start, int before, int count){
            //CATCH AN EXCEPTION WHEN THE INPUT IS NOT A NUMBER
            try {
                //num.mode(sp.getSelectedItemPosition());
                num.set(Double.parseDouble(Height.getText().toString()),Double.parseDouble(Weight.getText().toString()), Integer.parseInt(Age.getText().toString()),num.getbg(),sp.getSelectedItemPosition()+1);
            }catch (NumberFormatException e){
                num.set(0,0, 0,num.getbg(),1);
            }
            //comp();
        }
        public void afterTextChanged(Editable s) {}
        public void beforeTextChanged(CharSequence s,
                                      int start, int count, int after){}
    };


    public void reset(View view){
        num.setReset();
        if(num.getbg())
            bg.setText("男生");
        else
            bg.setText("女生");
        Height.setText(null);
        Weight.setText(null);
        Age.setText(null);
        text.setText("");
        sp.setSelection(0, false);
    }

    public void bg(View view){
        if(num.str())
            bg.setText("男生");//男生
        else
            bg.setText("女生");//女生
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.question, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
