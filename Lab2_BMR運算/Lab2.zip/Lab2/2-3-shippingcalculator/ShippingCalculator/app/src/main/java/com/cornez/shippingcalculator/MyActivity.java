package com.cornez.shippingcalculator;

import android.app.Activity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.InputFilter;

import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;



public class MyActivity extends Activity {
    //DATA MODEL FOR SHIP ITEM
    private ShipItem num;

    //VIEW OBJECTS FOR LAYOUT UI REFERENCE
    private EditText Weight;
    private EditText Height;
    private EditText Age;
    private TextView BMR;
    private TextView bg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_2);

        //CREATE THE DATA MODEL FOR STORING THE ITEM TO BE SHIPPED
        num = new ShipItem();

        //TASK 3: ESTABLISH THE REFERENCES TO INPUT WEIGHT ELEMENT
        Height = (EditText) findViewById(R.id.editText1);
        Weight = (EditText) findViewById(R.id.editText2);
        Age = (EditText) findViewById(R.id.editText3);

        //TASK 3: ESTABLISH THE REFERENCES TO OUTPUT ELEMENTS
        BMR = (TextView) findViewById(R.id.textView10);
        bg = (TextView) findViewById(R.id.bg);

        //TASK 4: REGISTER THE LISTENER EVENT FOR WEIGHT INPUT
        //Weight.addTextChangedListener(weightTextWatcher);
        Weight.addTextChangedListener(new DecimalInputTextWatcher(Weight, 5, 1));
        Height.addTextChangedListener(new DecimalInputTextWatcher(Height, 5, 1));

    }

    //private TextWatcher weightTextWatcher = new TextWatcher() {
    public class DecimalInputTextWatcher implements TextWatcher{
        //THE INPUT ELEMENT IS ATTACHED TO AN EDITABLE,
        //THEREFORE THESE METHODS ARE CALLED WHEN THE TEXT IS CHANGED

        private static final int DEFAULT_DECIMAL_DIGITS = 2;//預設 小數的位數  2 位

        private EditText editText;
        private int decimalDigits;// 小數的位數
        private int integerDigits;// 整數的位數

        public DecimalInputTextWatcher(EditText editText) {
            this.editText = editText;
            this.decimalDigits = DEFAULT_DECIMAL_DIGITS;
        }

        public DecimalInputTextWatcher(EditText editText, int decimalDigits) {
            this.editText = editText;
            if (decimalDigits <= 0)
                throw new RuntimeException("decimalDigits must > 0");
            this.decimalDigits = decimalDigits;
        }

        public DecimalInputTextWatcher(EditText editText, int integerDigits, int decimalDigits) {
            this.editText = editText;
            if (integerDigits <= 0)
                throw new RuntimeException("integerDigits must > 0");
            if (decimalDigits <= 0)
                throw new RuntimeException("decimalDigits must > 0");
            this.decimalDigits = decimalDigits;
            this.integerDigits = integerDigits;
        }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

        }

        @Override
        public void afterTextChanged(Editable editable) {
            String s = editable.toString();
            editText.removeTextChangedListener(this);

            if (s.contains(".")) {
                if (integerDigits > 0) {
                    editText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(integerDigits + decimalDigits + 1)});
                }
                if (s.length() - 1 - s.indexOf(".") > decimalDigits) {
                    s = s.substring(0,
                            s.indexOf(".") + decimalDigits + 1);
                    editable.replace(0, editable.length(), s.trim());//不輸入超出位數的數字
                }
            } else {
                if (integerDigits > 0) {
                    editText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(integerDigits + 1)});
                    if (s.length() > integerDigits) {
                        s = s.substring(0, integerDigits);
                        editable.replace(0, editable.length(), s.trim());
                    }
                }

            }
            if (s.trim().equals(".")) {//小數點開頭，小數點前補0
                s = "0" + s;
                editable.replace(0, editable.length(), s.trim());
            }
            if (s.startsWith("0") && s.trim().length() > 1) {//多個0開頭，只輸入一個0
                if (!s.substring(1, 2).equals(".")) {
                    editable.replace(0, editable.length(), "0");
                }
            }
            editText.addTextChangedListener(this);
        }
    };


    /*private TextWatcher weightTextWatcher = new TextWatcher() {
        //THE INPUT ELEMENT IS ATTACHED TO AN EDITABLE,
        //THEREFORE THESE METHODS ARE CALLED WHEN THE TEXT IS CHANGED

        public void onTextChanged(CharSequence s,
                                  int start, int before, int count){
            //CATCH AN EXCEPTION WHEN THE INPUT IS NOT A NUMBER
            try {
                shipItem.setWeight((int) Double.parseDouble(s.toString()));
            }catch (NumberFormatException e){
                shipItem.setWeight(0);
            }
            displayShipping();
        }
        public void afterTextChanged(Editable s) {}
        public void beforeTextChanged(CharSequence s,
                                      int start, int count, int after){}
    };


    private void displayShipping() {
        //DISPLAY THE BASE COST, ADDED COST, AND TOTAL COST
        baseCostTV.setText("$" + String.format("%.02f",
                shipItem.getWeight()));
        addedCostTV.setText("$" + String.format("%.02f",
                shipItem.getHeight()));
        totalCostTV.setText("$" + String.format("%.02f",
                shipItem.getBMR()));
    }

    */


    public void comp(View view){
        String Height_textip=Height.getText().toString().trim();
        String Height_textinfo =Height.getText().toString();
        String Weight_textip=Weight.getText().toString().trim();
        String Weight_textinfo =Weight.getText().toString();
        String Age_textip=Age.getText().toString().trim();
        String Age_textinfo =Age.getText().toString();
        if(null == Age_textinfo || "".equals(Age_textinfo)||Age_textip.isEmpty()||
                null == Weight_textinfo || "".equals(Weight_textinfo)||Weight_textip.isEmpty()||
                null == Height_textinfo || "".equals(Height_textinfo)||Height_textip.isEmpty())
        {BMR.setText("請完整輸入！");}//判斷Info輸入框是否為空//判斷IP輸入框是否為空
        ///////////////////////////////////////////////判斷是否輸入完全
        else{
            num.set(Double.parseDouble(Height.getText().toString()),Double.parseDouble(Weight.getText().toString()), Integer.parseInt(Age.getText().toString()));
            BMR.setText(num.getBMR().toString());
        }

    }

    public void reset(View view){
       num.setReset();
        if(num.getbg())
            bg.setText("男生");
        else
            bg.setText("女生");
       BMR.setText("0.0");
       Height.setText(null);
       Weight.setText(null);
       Age.setText(null);
    }

    public void bg(View view){
        if(num.str())
            bg.setText("男生");
        else
            bg.setText("女生");
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.my, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
